## 2025-02-10
- Update README
- Moved include unistd to top of file in spinapi.c
- Changed make install path to /opt/spinapi
- Included README.txt for make install within top directory CMakeLists
- Free file descriptor, dir, path_to_resource0 for PCIe access utils_linux

## 2024-12-11
- Removal of iopl checks to allow non-root users to run PCI/PCIe boards

## 2022-08-24
- Added memory mapping for PCIe products
- Added USB-PTS support
