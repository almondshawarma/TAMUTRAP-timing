SpinAPI Linux Read Me

Table of Contents

    Overview
    Compilation Support
    Device Permissions and UEFI Boot Mode
        Device Permissions
        UEFI
        udev File


Overview
========

The 20250210 x86_64 version supports PulseBlaster, PulseBlasterDDS-I-300, PulseBlasterDDS-II, PulseBlasterDDS-III, PulseBlasterESR, PulseBlasterESR-PRO, PulseBlasterESR-PRO-II, PB-DualCore, PB-QuadCore, USB-PTS, and RadioProcessor boards.

The contents of each directory is explained below.

examples    - contains the source code for the SpinAPI examples
include     - contains the SpinAPI headers
interpreter - SpinAPI command line interface
src         - contains the source code for the SpinAPI library

Compilation Support
===================

Required packages, on Ubuntu 24.04: build-essential cmake

Required packages, on Fedora 36: cmake gcc-c++

If you are cross compiling, also install: gcc-multilib g++multilib

CMake version 3.6 or later is required.

To perform a full rebuild of SpinAPI and the examples:

    cd SpinAPI_linux-20250210-x86_64
    mkdir build
    cd build
    cmake ..
    make

The freshly compiled programs will be inside the build directory, for example:

    cd SpinAPI_linux-20250210-x86_64
    sudo ./build/examples/General/pb_read_firmware


Note that root privileges are required, or the programs may segfault.

Device Permissions and UEFI Boot Mode
=====================================

Device Permissions

Device permissions must be set properly to use SpinCore devices. One way to attain this permission is to run as root or use sudo before an executable.

If running root or using sudo is not possible, using udev rules for USB/PCIe products or setcap for PCI products is an alternative.

An example of a udev file is provided in the udev File section below.

For PCI products, you can set the capabilities of each executable to allow IO permissions through use of the setcap command. For example:

   sudo setcap cap_sys_rawio=ep ./pb24_ex1

will provide IO port access to all users for the executable pb24_ex1.


UEFI

UEFI Boot Mode may default to disabling IO/Memory access for the SpinCore devices. If this is the case, you will need to enable IO/Memory space for the device or use Legacy Boot Mode. If you prefer to enable the IO/Memory access via udev rules, the .rules file below has the rule for certain PCIe and PCI boards.


udev File

An example udev rules file can be found at 99-spincore-linux.rules (https://spincore.com/support/spinapi/99-spincore-linux.rules). This file should typically be placed in "/etc/udev/rules.d/", but this path may vary depending on your Linux distribution. Remove the comment (#) for the product you would like to have a udev rule for. Once the rules file has been added, you can update the system rules using the command "sudo udevadm control --reload-rules && sudo udevadm trigger".

Note: The PCIe and USB device permissions section use a group called spincore. In order for the rule to work correctly, please make sure that you have a group called spincore before applying the udev rules. To create a new group called spincore, the following below can be ran:

   sudo addgroup spincore
